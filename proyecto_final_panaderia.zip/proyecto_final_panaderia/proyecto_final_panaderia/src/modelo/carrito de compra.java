import java.util.ArrayList;

public class Carrito {
    private ArrayList<Producto> productos;

    public Carrito() {
        productos = new ArrayList<>();
    }

    public void agregarProducto(Producto p) {
        // Si producto ya está, aumentar cantidad
        for (Producto prod : productos) {
            if (prod.getNombre().equals(p.getNombre())) {
                prod.setCantidad(prod.getCantidad() + p.getCantidad());
                return;
            }
        }
        productos.add(p);
    }

    public void eliminarProducto(String nombre) {
        productos.removeIf(prod -> prod.getNombre().equals(nombre));
    }

    public double calcularTotal() {
        double total = 0;
        for (Producto p : productos) {
            total += p.getSubtotal();
        }
        return total;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }
}
