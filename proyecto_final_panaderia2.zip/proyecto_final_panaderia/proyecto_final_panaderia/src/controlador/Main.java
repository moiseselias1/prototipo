package controlador;

import javax.swing.SwingUtilities;
import vista.VentanaPrincipal;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);  // ✅ ya no dará error
        });
    }
}
