package modelo;

import java.util.Objects;

public class Producto {
    private String nombre;
    private double precio;
    private String imagen;
    
    public Producto(String nombre, double precio, String imagen) {
        this.nombre = nombre;
        this.precio = precio;
        this.imagen = imagen;
    }

    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public String getImagen() { return imagen; }

  
    @Override
    public String toString() {
        return nombre + " - $" + String.format("%.2f", precio);
    }

    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Producto)) return false;
        Producto producto = (Producto) o;
        return Double.compare(producto.precio, precio) == 0 &&
               Objects.equals(nombre, producto.nombre) &&
               Objects.equals(imagen, producto.imagen);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, precio, imagen);
    }
}
