package controlador;

import vista.VentanaLogin;

public class Main {
    public static void main(String[] args) {
        new VentanaLogin().setVisible(true);
    }
}
