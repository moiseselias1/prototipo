package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaLogin extends JFrame {
    private JTextField campoUsuario;
    private JPasswordField campoContraseña;
    private JButton botonLogin;

    public VentanaLogin() {
        setTitle("Inicio de Sesión");
        setSize(350, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setBackground(new Color(240, 248, 255)); 
        panelPrincipal.setLayout(new GridLayout(4, 2, 10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setContentPane(panelPrincipal);

        JLabel etiquetaUsuario = new JLabel("Usuario:");
        etiquetaUsuario.setForeground(new Color(25, 25, 112)); 
        campoUsuario = new JTextField();
        campoUsuario.setBackground(Color.WHITE);
        campoUsuario.setForeground(Color.BLACK);

        JLabel etiquetaContraseña = new JLabel("Contraseña:");
        etiquetaContraseña.setForeground(new Color(25, 25, 112));
        campoContraseña = new JPasswordField();
        campoContraseña.setBackground(Color.WHITE);
        campoContraseña.setForeground(Color.BLACK);

        botonLogin = new JButton("Iniciar sesión");
        botonLogin.setBackground(new Color(100, 149, 237)); 
        botonLogin.setForeground(Color.WHITE);
        botonLogin.setFocusPainted(false);

        // Eventos
        botonLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();
                String contraseña = new String(campoContraseña.getPassword());

                if (validarCredenciales(usuario, contraseña)) {
                    dispose(); // Cierra login
                    new VentanaPrincipal().setVisible(true); 
                } else {
                    JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panelPrincipal.add(etiquetaUsuario);
        panelPrincipal.add(campoUsuario);
        panelPrincipal.add(etiquetaContraseña);
        panelPrincipal.add(campoContraseña);
        panelPrincipal.add(new JLabel()); 
        panelPrincipal.add(new JLabel());  
        panelPrincipal.add(new JLabel());  
        panelPrincipal.add(botonLogin);
    }

    private boolean validarCredenciales(String usuario, String contraseña) {
         
        return usuario.equals("pan") && contraseña.equals("12");
    }
}
