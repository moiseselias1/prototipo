package modelo;

import java.io.*;
import javax.swing.DefaultListModel;

public class ArchivoTexto {
    public static void escribir(String ruta, String contenido) {
        try (FileWriter escritor = new FileWriter(ruta, true)) {
            escritor.write(contenido + System.lineSeparator());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void leerYAgregarAlModelo(String ruta, DefaultListModel<String> modelo) {
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                modelo.addElement(linea);
            }
        } catch (IOException e) {
            // No hace nada si el archivo no existe (primer uso)
        }
    }
}
