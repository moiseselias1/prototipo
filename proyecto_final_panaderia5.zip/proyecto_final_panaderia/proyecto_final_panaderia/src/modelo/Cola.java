package modelo;

public class Cola<T> {
    private NodoCola<T> frente, fin;

    public void encolar(T dato) {
        NodoCola<T> nuevo = new NodoCola<>(dato);
        if (fin != null) fin.siguiente = nuevo;
        else frente = nuevo;
        fin = nuevo;
    }

    public T desencolar() {
        if (frente == null) return null;
        T dato = frente.dato;
        frente = frente.siguiente;
        if (frente == null) fin = null;
        return dato;
    }

    public boolean estaVacia() { return frente == null; }
}

class NodoCola<T> {
    T dato;
    NodoCola<T> siguiente;
    NodoCola(T dato) { this.dato = dato; }
}
