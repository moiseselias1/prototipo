package modelo;

public class ListaCircular<T> {
    private NodoCircular<T> actual = null;

    public void agregar(T dato) {
        NodoCircular<T> nuevo = new NodoCircular<>(dato);
        if (actual == null) {
            actual = nuevo;
            actual.siguiente = actual;
        } else {
            NodoCircular<T> temp = actual;
            while (temp.siguiente != actual) temp = temp.siguiente;
            temp.siguiente = nuevo;
            nuevo.siguiente = actual;
        }
    }

    public void avanzar() {
        if (actual != null) actual = actual.siguiente;
    }

    public T obtenerActual() {
        return actual != null ? actual.dato : null;
    }
}

class NodoCircular<T> {
    T dato;
    NodoCircular<T> siguiente;
    NodoCircular(T dato) { this.dato = dato; }
}
