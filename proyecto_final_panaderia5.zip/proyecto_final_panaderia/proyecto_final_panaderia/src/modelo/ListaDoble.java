package modelo;

public class ListaDoble<T> {
    private NodoDoble<T> cabeza, cola;

    public void agregarAlFinal(T dato) {
        NodoDoble<T> nuevo = new NodoDoble<>(dato);
        if (cabeza == null) {
            cabeza = cola = nuevo;
        } else {
            cola.siguiente = nuevo;
            nuevo.anterior = cola;
            cola = nuevo;
        }
    }

    public void eliminar(T dato) {
        NodoDoble<T> actual = cabeza;
        while (actual != null) {
            if (actual.dato.equals(dato)) {
                if (actual.anterior != null) actual.anterior.siguiente = actual.siguiente;
                else cabeza = actual.siguiente;
                if (actual.siguiente != null) actual.siguiente.anterior = actual.anterior;
                else cola = actual.anterior;
                break;
            }
            actual = actual.siguiente;
        }
    }

    // Recorre la lista hacia adelante
    public void imprimir() {
        NodoDoble<T> actual = cabeza;
        while (actual != null) {
            System.out.println(actual.dato);
            actual = actual.siguiente;
        }
    }
}

class NodoDoble<T> {
    T dato;
    NodoDoble<T> anterior, siguiente;
    NodoDoble(T dato) { this.dato = dato; }
}
