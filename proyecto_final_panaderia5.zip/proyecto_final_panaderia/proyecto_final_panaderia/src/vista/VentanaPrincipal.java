package vista;

import modelo.CarritoCompras;
import modelo.ItemCarrito;
import modelo.Producto;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class VentanaPrincipal extends JFrame {

    // --- Modelos de Listas ---
    private DefaultListModel<Producto> listaProductosModel;
    private DefaultListModel<String> carritoModel;
    private DefaultListModel<Producto> favoritosModel;
    private DefaultListModel<String> historialModel;

    // --- Componentes de la Interfaz ---
    private JList<Producto> listaProductos;
    private JList<String> listaCarrito;
    private JList<Producto> listaFavoritos;
    private JList<String> listaHistorial;
    private JButton btnEliminarFavorito;
    private JLabel lblTotal;

    // --- Lógica de Negocio ---
    private CarritoCompras carrito;

    public VentanaPrincipal() {
        // --- Configuración de la Ventana Principal ---
        setTitle("Carrito de Compras");
        setSize(1200, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // --- Inicialización de Modelos y Carrito ---
        carrito = new CarritoCompras();
        listaProductosModel = new DefaultListModel<>();
        carritoModel = new DefaultListModel<>();
        favoritosModel = new DefaultListModel<>();
        historialModel = new DefaultListModel<>();

        // --- Inicialización de JLists ---
        listaProductos = new JList<>(listaProductosModel);
        listaCarrito = new JList<>(carritoModel);
        listaFavoritos = new JList<>(favoritosModel);
        listaHistorial = new JList<>(historialModel);

        // --- Configuración de Renderers para JLists ---
        listaProductos.setCellRenderer(getProductoRenderer());
        listaFavoritos.setCellRenderer(getProductoRenderer());

        // --- Componente para mostrar el Total ---
        lblTotal = new JLabel("Total: $0.00", SwingConstants.CENTER);

        // --- Creación de Botones Principales ---
        JButton btnAgregar = new JButton("Agregar al carrito");
        JButton btnEliminar = new JButton("Eliminar del carrito");
        JButton btnVaciar = new JButton("Vaciar carrito");
        JButton btnAgregarFavorito = new JButton("Agregar a Favoritos");
        JButton btnFinalizarCompra = new JButton("Finalizar Compra");
        // Cambiado el nombre del botón de "Salir" a "Cerrar Sesión"
        JButton btnCerrarSesion = new JButton("Cerrar Sesión");

        // --- Asignación de Acciones a los Botones ---
        btnAgregar.addActionListener(e -> agregarAlCarrito());
        btnEliminar.addActionListener(e -> eliminarDelCarrito());
        btnVaciar.addActionListener(e -> vaciarCarrito());
        btnAgregarFavorito.addActionListener(e -> agregarAFavoritos());
        btnFinalizarCompra.addActionListener(e -> finalizarCompra());
        // Acción para el nuevo botón "Cerrar Sesión"
        btnCerrarSesion.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "¿Estás seguro que deseas cerrar sesión?",
                    "Confirmar Cierre de Sesión",
                    JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                // Aquí puedes agregar la lógica para cerrar la sesión,
                // como limpiar datos de usuario, volver a una pantalla de login, etc.
                // Por ahora, simplemente cierra la aplicación.
                System.exit(0);
            }
        });

        // --- Panel de Productos Disponibles ---
        JPanel panelProductos = new JPanel(new BorderLayout(10, 10));
        panelProductos.setBorder(BorderFactory.createTitledBorder("Productos Disponibles"));
        panelProductos.add(new JScrollPane(listaProductos), BorderLayout.CENTER);

        JPanel panelBotonesProductos = new JPanel(new GridLayout(1, 2, 10, 0));
        panelBotonesProductos.add(btnAgregar);
        panelBotonesProductos.add(btnAgregarFavorito);
        panelProductos.add(panelBotonesProductos, BorderLayout.SOUTH);

        // --- Panel del Carrito de Compras ---
        JPanel panelCarrito = new JPanel(new BorderLayout(10, 10));
        panelCarrito.setBorder(BorderFactory.createTitledBorder("Carrito"));
        panelCarrito.add(new JScrollPane(listaCarrito), BorderLayout.CENTER);

        JPanel panelBotonesCarrito = new JPanel(new GridLayout(1, 3, 10, 0));
        panelBotonesCarrito.add(btnEliminar);
        panelBotonesCarrito.add(btnVaciar);
        panelBotonesCarrito.add(btnFinalizarCompra);

        panelCarrito.add(lblTotal, BorderLayout.NORTH);
        panelCarrito.add(panelBotonesCarrito, BorderLayout.SOUTH);

        // --- Panel de Favoritos ---
        JPanel panelFavoritos = new JPanel(new BorderLayout(10, 10));
        panelFavoritos.setBorder(BorderFactory.createTitledBorder("Favoritos"));
        panelFavoritos.add(new JScrollPane(listaFavoritos), BorderLayout.CENTER);

        btnEliminarFavorito = new JButton("Eliminar favorito");
        btnEliminarFavorito.addActionListener(e -> eliminarFavorito());
        panelFavoritos.add(btnEliminarFavorito, BorderLayout.SOUTH);

        // --- Panel de Historial de Compras ---
        JPanel panelHistorial = new JPanel(new BorderLayout(10, 10));
        panelHistorial.setBorder(BorderFactory.createTitledBorder("Historial de Compras"));
        panelHistorial.add(new JScrollPane(listaHistorial), BorderLayout.CENTER);
        
        // Cargar historial desde archivo
        modelo.ArchivoTexto.leerYAgregarAlModelo("historial.txt", historialModel);

        // --- Organización de Paneles Principales ---
        JPanel panelIzquierda = new JPanel(new BorderLayout(10, 10));
        panelIzquierda.add(panelProductos, BorderLayout.CENTER);
        panelIzquierda.add(panelFavoritos, BorderLayout.SOUTH);

        JPanel panelDerecha = new JPanel(new GridLayout(2, 1, 10, 10));
        panelDerecha.add(panelCarrito);
        panelDerecha.add(panelHistorial);

        JPanel panelPrincipal = new JPanel(new GridLayout(1, 2, 15, 15));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelPrincipal.add(panelIzquierda);
        panelPrincipal.add(panelDerecha);

        // --- Añadir el panel principal y el botón de Cerrar Sesión ---
        add(panelPrincipal, BorderLayout.CENTER); // Usamos BorderLayout para añadir el botón abajo
        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelInferior.add(btnCerrarSesion);
        add(panelInferior, BorderLayout.SOUTH);

        // --- Cargar productos de ejemplo al iniciar ---
        cargarProductosEjemplo();
    }

    // --- Método para el Renderer Personalizado de Productos ---
    private ListCellRenderer<? super Producto> getProductoRenderer() {
        return (list, value, index, isSelected, cellHasFocus) -> {
            JPanel panel = new JPanel(new BorderLayout(5, 5));
            panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            JLabel lblNombre = new JLabel(value.getNombre());
            JLabel lblPrecio = new JLabel("$" + value.getPrecio());
            JLabel lblImagen = new JLabel();

            ImageIcon icon = new ImageIcon("images/" + value.getImagen());
            Image img = icon.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
            lblImagen.setIcon(new ImageIcon(img));

            JPanel textPanel = new JPanel(new GridLayout(0, 1));
            textPanel.add(lblNombre);
            textPanel.add(lblPrecio);

            panel.add(lblImagen, BorderLayout.WEST);
            panel.add(textPanel, BorderLayout.CENTER);

            if (isSelected) {
                panel.setBackground(list.getSelectionBackground());
                panel.setForeground(list.getSelectionForeground());
            } else {
                panel.setBackground(list.getBackground());
                panel.setForeground(list.getForeground());
            }
            return panel;
        };
    }

    // --- Métodos de Lógica de la Aplicación ---

    /**
     * Carga una serie de productos de ejemplo en la lista de productos disponibles.
     */
    private void cargarProductosEjemplo() {
        listaProductosModel.addElement(new Producto("Pan de queso", 1000.0, "pan_queso.jpg"));
        listaProductosModel.addElement(new Producto("Pan de trigo", 1500.0, "pan_trigo.jpg"));
        listaProductosModel.addElement(new Producto("Pan integral", 1000.0, "pan_integral.jpg"));
        listaProductosModel.addElement(new Producto("Pan de maíz", 1200.0, "pan_maiz.jpg"));
        listaProductosModel.addElement(new Producto("Pan aliñado", 1000.0, "pan_aliñado.jpg"));
        listaProductosModel.addElement(new Producto("Pan de arequipe", 2000.0, "pan_arequipe.jpg"));
        listaProductosModel.addElement(new Producto("Pan de mantequilla", 1500.0, "pan_mantequilla.jpg"));
        listaProductosModel.addElement(new Producto("Pan de bocadillo", 3000.0, "pan_bocadillo.jpg"));
        listaProductosModel.addElement(new Producto("Pan de sal", 500.0, "pan_sal.jpg"));
        listaProductosModel.addElement(new Producto("Croissant", 2500.0, "croissant.jpg"));
        listaProductosModel.addElement(new Producto("Pan de uva pasas", 3500.0, "pan_uva_pasas.jpg"));
    }

    /**
     * Agrega el producto seleccionado de la lista de productos al carrito de compras.
     * Muestra un mensaje si no hay ningún producto seleccionado.
     */
    private void agregarAlCarrito() {
        Producto seleccionado = listaProductos.getSelectedValue();
        if (seleccionado != null) {
            carrito.agregarProducto(seleccionado, 1);
            actualizarCarrito();
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un producto para agregar.");
        }
    }

    /**
     * Elimina el producto seleccionado del carrito de compras.
     * Muestra un mensaje si no hay ningún producto seleccionado en el carrito.
     */
    private void eliminarDelCarrito() {
        int index = listaCarrito.getSelectedIndex();
        if (index >= 0) {
            List<ItemCarrito> items = carrito.getItems();
            ItemCarrito item = items.get(index);
            carrito.eliminarProducto(item.getProducto());
            actualizarCarrito();
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un producto para eliminar.");
        }
    }

    /**
     * Vacía completamente el carrito de compras.
     */
    private void vaciarCarrito() {
        carrito.vaciar();
        actualizarCarrito();
    }

    /**
     * Actualiza la visualización de los elementos en el carrito y el total.
     */
    private void actualizarCarrito() {
        carritoModel.clear();
        List<ItemCarrito> items = carrito.getItems();
        for (ItemCarrito item : items) {
            carritoModel.addElement(item.getProducto().getNombre() + " x" + item.getCantidad() +
                    " - $" + String.format("%.2f", item.getProducto().getPrecio() * item.getCantidad()));
        }
        lblTotal.setText("Total: $" + String.format("%.2f", carrito.calcularTotal()));
    }

    /**
     * Agrega el producto seleccionado de la lista de productos a la lista de favoritos.
     * Muestra un mensaje si el producto ya está en favoritos o si no hay ninguno seleccionado.
     */
    private void agregarAFavoritos() {
        Producto seleccionado = listaProductos.getSelectedValue();
        if (seleccionado != null) {
            if (!favoritosModel.contains(seleccionado)) {
                favoritosModel.addElement(seleccionado);
            } else {
                JOptionPane.showMessageDialog(this, "El producto ya está en favoritos.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un producto para agregar a favoritos.");
        }
    }

    /**
     * Elimina el producto seleccionado de la lista de favoritos.
     * Muestra un mensaje si no hay ningún producto favorito seleccionado.
     */
    private void eliminarFavorito() {
        int index = listaFavoritos.getSelectedIndex();
        if (index >= 0) {
            favoritosModel.remove(index);
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un producto favorito para eliminar.");
        }
    }

    /**
     * Finaliza la compra, transfiere los productos del carrito al historial de compras,
     * vacía el carrito y muestra un mensaje de éxito. Recarga los productos disponibles.
     */
    private void finalizarCompra() {
        if (carrito.getItems().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El carrito está vacío.");
            return;
        }
        
        for (ItemCarrito item : carrito.getItems()) {
    String registro = item.getProducto().getNombre() + " x" + item.getCantidad();
    historialModel.addElement(registro);
    modelo.ArchivoTexto.escribir("historial.txt", registro); // <-- Aquí guardas en archivo
       }


      
        JOptionPane.showMessageDialog(this, "✅ Compra exitosa. ¡Gracias por tu compra!");

        carrito.vaciar();
        actualizarCarrito();

        // Recargar productos después de la compra
        listaProductosModel.clear();
        cargarProductosEjemplo();
    }

    // --- Método Principal ---
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventana = new VentanaPrincipal();
            ventana.setVisible(true);
        });
    }
}